import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-docconversion',
  templateUrl: './docconversion.component.html',
  styleUrls: ['./docconversion.component.css']
})
export class DocconversionComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
