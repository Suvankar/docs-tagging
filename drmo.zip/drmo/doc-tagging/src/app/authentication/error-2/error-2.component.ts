import { Component } from '@angular/core'

@Component({
    templateUrl: './error-2.component.html'
})

export class Error2Component {
   
}    