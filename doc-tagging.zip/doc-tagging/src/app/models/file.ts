export class FileDetails {
  name: string;
  url: string;
}
