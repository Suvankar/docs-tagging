import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mydocuments',
  templateUrl: './mydocuments.component.html',
  styleUrls: ['./mydocuments.component.css']
})
export class MydocumentsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
