import { NgModule } from '@angular/core';

import { SharedModule } from '../shared/shared.module';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import { PagesRoutingModule } from './pages-routing.module';
import {NzCardModule} from 'ng-zorro-antd/card';
import {NzSkeletonModule} from 'ng-zorro-antd/skeleton';
import {NzAvatarModule} from 'ng-zorro-antd/avatar';
import {NzDividerModule} from 'ng-zorro-antd/divider';
import {NzListModule} from 'ng-zorro-antd/list';
import {NzPaginationModule} from 'ng-zorro-antd/pagination';
import {NzButtonModule} from 'ng-zorro-antd/button';
import {NzTableModule} from 'ng-zorro-antd/table';
import {NzRadioModule} from 'ng-zorro-antd/radio';
import {NzRateModule} from 'ng-zorro-antd/rate';
import {NzTabsModule} from 'ng-zorro-antd/tabs';
import {NzFormModule} from 'ng-zorro-antd/form';
import {NzDatePickerModule} from 'ng-zorro-antd/date-picker';
import {NzSelectModule} from 'ng-zorro-antd/select';
import {NzUploadModule} from 'ng-zorro-antd/upload';
import {NzSwitchModule} from 'ng-zorro-antd/switch';
import {NzToolTipModule} from 'ng-zorro-antd/tooltip';
import {NzMessageModule} from 'ng-zorro-antd/message';
import {NzModalModule} from 'ng-zorro-antd/modal';
import {NzTagModule} from 'ng-zorro-antd/tag';
import {NzInputModule} from 'ng-zorro-antd/input';
import { SearchdocumnetsComponent } from './searchdocumnets/searchdocumnets.component';
import { ViewdocumentsComponent } from './viewdocuments/viewdocuments.component';
import { MydocumentsComponent } from './mydocuments/mydocuments.component';
import { AdvancesearchComponent } from './advancesearch/advancesearch.component';
import { UploaddocumentComponent } from './uploaddocument/uploaddocument.component';
import { SearchresultComponent } from './searchresult/searchresult.component';
import {NzBadgeModule} from 'ng-zorro-antd/badge';
import {NzLayoutModule} from 'ng-zorro-antd/layout';
import {QuicklinkModule} from 'ngx-quicklink';
import {NzIconModule} from 'ng-zorro-antd/icon';
import {NzCollapseModule} from 'ng-zorro-antd/collapse';


const antdModule = [
    NzCardModule,
    NzSkeletonModule,
    NzAvatarModule,
    NzPaginationModule,
    NzDividerModule,
    NzButtonModule,
    NzListModule,
    NzTableModule,
    NzRadioModule,
    NzRateModule,
    NzTabsModule,
    NzTagModule,
    NzFormModule,
    NzDatePickerModule,
    NzSelectModule,
    NzSwitchModule,
    NzUploadModule,
    NzToolTipModule,
    NzModalModule,
    NzMessageModule,
    NzInputModule,
    NzBadgeModule,
    NzLayoutModule,
    NzIconModule,
   NzCollapseModule

];

@NgModule({
  imports: [
    SharedModule,
    ReactiveFormsModule,
    PagesRoutingModule,
    FormsModule,
    ...antdModule,
    QuicklinkModule
  ],
    declarations: [


    SearchdocumnetsComponent,
           ViewdocumentsComponent,
           MydocumentsComponent,
           AdvancesearchComponent,
           UploaddocumentComponent,
           SearchresultComponent
  ],
    providers: [
    ]
})

export class PagesModule {}
