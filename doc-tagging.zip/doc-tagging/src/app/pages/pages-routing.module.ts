import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {AdvancesearchComponent} from './advancesearch/advancesearch.component';
import {MydocumentsComponent} from './mydocuments/mydocuments.component';
import {UploaddocumentComponent} from './uploaddocument/uploaddocument.component';
import {ViewdocumentsComponent} from './viewdocuments/viewdocuments.component';
import {SearchresultComponent} from './searchresult/searchresult.component';



const routes: Routes = [
  {
    path: 'advancesearch',
    component: AdvancesearchComponent,
    data: {
      title: 'Advance Search',
      headerDisplay: 'none'
    }
  },
  {
    path: 'mydocs',
    component: MydocumentsComponent,
    data: {
      title: 'My Uploaded Documents',
      headerDisplay: 'none'
    }
  },
  {
    path: 'uploader',
    component: UploaddocumentComponent,
    data: {
      title: 'Upload Documents',
      headerDisplay: 'none'
    }
  },
  {
    path: 'viewdocument/:docid',
    component: ViewdocumentsComponent,
    data: {
      title: 'View Documents',
      headerDisplay: 'none'
    }
  },
  {
    path: 'searchresult',
    component: SearchresultComponent,
    data: {
      title: 'Search Result',
      headerDisplay: 'none'
    }
  },
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule],
})
export class PagesRoutingModule { }
