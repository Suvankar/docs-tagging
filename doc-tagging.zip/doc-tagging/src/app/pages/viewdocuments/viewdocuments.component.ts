import { Component, OnInit } from '@angular/core';
import {ThemeConstantService} from '../../shared/services/theme-constant.service';
import {NzUploadFile} from 'ng-zorro-antd/upload/interface';
import {DatePipe} from '@angular/common';

let blogData = require('../../../assets/data/pages/data.json');
declare var require: any;

@Component({
  selector: 'app-viewdocuments',
  templateUrl: './viewdocuments.component.html',
  styleUrls: ['./viewdocuments.component.css']
})
export class ViewdocumentsComponent implements OnInit {

  themeColors = this.colorConfig.get().colors;
  colorRed = this.themeColors.red;
  colorBlue = this.themeColors.blue;
  colorCyan = this.themeColors.cyan;
  colorGold = this.themeColors.gold;
  colorVolcano = this.themeColors.volcano;
  colorPurple = this.themeColors.purple;
  type;
  blog ;
  loading = true;
  tags = [];
  isPIData = false;
  file: NzUploadFile;

  constructor(private colorConfig: ThemeConstantService, private date: DatePipe) {
    this.blog = blogData;

    setTimeout(() => {
      this.loading = false;
    }, 1000);
  }

  ngOnInit(): void {
    this.isPIData = JSON.parse(localStorage.getItem('PII')) as boolean;
    this.tags = JSON.parse(localStorage.getItem('tags')) ;
    this.file = JSON.parse(localStorage.getItem('file')) as NzUploadFile ;
    this.type = this.file.type.split('/')[1];
    console.log(this.isPIData);
    console.log(this.tags);
    console.log(this.file);
  }

  sliceTagName(tag: string): string {
    const isLongTag = tag.length > 20;
    return isLongTag ? `${tag.slice(0, 20)}...` : tag;
  }

}
