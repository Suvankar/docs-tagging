import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-viewdocuments',
  templateUrl: './viewdocuments.component.html',
  styleUrls: ['./viewdocuments.component.css']
})
export class ViewdocumentsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
