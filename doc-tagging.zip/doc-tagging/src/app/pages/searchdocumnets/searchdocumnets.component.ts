import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-searchdocumnets',
  templateUrl: './searchdocumnets.component.html',
  styleUrls: ['./searchdocumnets.component.css']
})
export class SearchdocumnetsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
