import { SideNavInterface } from '../../interfaces/side-nav.type';
export const ROUTES: SideNavInterface[] = [
    {
        path: '/dashboard/home',
        title: 'Dashboard',
        iconType: 'nzIcon',
        iconTheme: 'outline',
        icon: 'dashboard',
        submenu: []
    },
  {
    path: '/pages/advancesearch',
    title: 'Search',
    iconType: 'nzIcon',
    iconTheme: 'outline',
    icon: 'file-search',
    submenu: []
  },
  {
    path: '/pages/uploader',
    title: 'Upload Docs',
    iconType: 'nzIcon',
    iconTheme: 'outline',
    icon: 'cloud-upload',
    submenu: []
  },
  {
    path: '/pages/mydocs',
    title: 'My Docs',
    iconType: 'nzIcon',
    iconTheme: 'outline',
    icon: 'file-text',
    submenu: []
  }

]
