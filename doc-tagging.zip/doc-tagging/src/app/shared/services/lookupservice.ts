import { Injectable } from '@angular/core';
import {HttpClient, HttpHeaders, HttpParams} from '@angular/common/http';
import {Observable, Subject, throwError} from 'rxjs';
import { catchError, retry } from 'rxjs/operators';

import {FileDetails} from '../../models/file';


@Injectable({
  providedIn: 'root'
})
export class Lookupservice {

  filesUrl = 'http://localhost:8888/files';


  constructor(private http: HttpClient) { }

  getAllFiles( ){
    return this.http.get<FileDetails[]>(this.filesUrl ).pipe(
      catchError(this.handleError)
    );
  }

  handleError(){
    return null;
  }


}
